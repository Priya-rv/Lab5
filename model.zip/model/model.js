const mongoose=require('mongoose');

const Item=mongoose.Schema({
    name:String,
    price:Number,
    quant:Number
})

module.exports=mongoose.model('Item', Item);